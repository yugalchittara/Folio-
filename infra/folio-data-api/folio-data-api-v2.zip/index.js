"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { Pool } = require("pg");

const schema = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8");
let pool;

function database() {
  const hasConnectionString = Boolean(process.env.DATABASE_URL);
  if (!hasConnectionString && !(process.env.PGHOST && process.env.PGDATABASE && process.env.PGUSER && process.env.PGPASSWORD)) {
    throw new Error("Database connection variables are not configured.");
  }
  if (!pool) {
    pool = new Pool({
      ...(hasConnectionString
        ? { connectionString: process.env.DATABASE_URL }
        : {
          host: process.env.PGHOST,
          port: Number(process.env.PGPORT ?? "5432"),
          database: process.env.PGDATABASE,
          user: process.env.PGUSER,
          password: process.env.PGPASSWORD,
        }),
      ssl: process.env.PGSSLMODE === "disable" ? false : { rejectUnauthorized: false },
      max: 2,
    });
  }
  return pool;
}

function response(statusCode, body) {
  return {
    statusCode,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
    body: JSON.stringify(body),
  };
}

function authorized(event) {
  const configured = process.env.FOLIO_DATA_API_TOKEN;
  const headers = event.headers || {};
  const supplied = headers.authorization || headers.Authorization || headers["x-folio-data-token"];
  return Boolean(configured && supplied === `Bearer ${configured}`);
}

exports.handler = async (event) => {
  if (event.requestContext?.http?.method === "OPTIONS") return response(204, {});
  if (!authorized(event)) return response(401, { error: "Unauthorized" });

  try {
    const body = event.body ? JSON.parse(event.body) : {};
    if (body.action === "health") {
      await database().query("SELECT 1");
      return response(200, { ok: true });
    }
    if (body.action === "migrate") {
      await database().query(schema);
      return response(200, { ok: true, message: "Folio schema is ready." });
    }
    return response(400, { error: "Unsupported data operation" });
  } catch (error) {
    console.error(error);
    return response(500, { error: "Data service unavailable" });
  }
};
